import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MainJava {
    public static void main(String[] args) {

        try{
            File f =new File("C:\\Users\\8146q\\IdeaProjects\\DS_11_202002546\\src\\input.txt");
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            List<String> alines = new ArrayList<>();
            while((line = br.readLine())!=null){
                alines.add(line);
            }
            while(alines.isEmpty()==false){
                AVLTree tree = new AVLTree();
                String[] splited = alines.remove(0).split(" ");
                int k = Integer.valueOf(alines.remove(0));
                for(int i = 0; i < splited.length; i++){
                    int key = Integer.valueOf(splited[i]);
                    tree.put(key,0);
                }

                tree.preorder(tree.getRoot());
                System.out.println();
                System.out.println(tree.getLeftSize());
                System.out.println("=========");
                tree.deleteKth(k);
                tree.preorder(tree.getRoot());
                System.out.println();
                System.out.println(tree.getLeftSize());
                System.out.println();
                System.out.println("=========");
            }

        }catch(FileNotFoundException e){
            System.out.println("FileNotFoundException");
        }catch(IOException e){
            System.out.println("IOException");
        }
    }

}