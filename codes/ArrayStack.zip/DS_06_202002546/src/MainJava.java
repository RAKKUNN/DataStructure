import java.io.*;

public class MainJava {
    public static int getPriority(char symbol){
        if (symbol == '+' || symbol == '-') {
            return 1;
        } else if (symbol == '*' || symbol == '/') {
            return 2;
        } else {
            return -1;
        }
    }
    public static String Change(String unchanged_fn) {
        int n = unchanged_fn.length();
        char[] changed_fn = new char[n];
        ArrayStack stack = new ArrayStack(n);
        int top = -1;

        for (int i = 0; i < n; i++) {
            char c = unchanged_fn.charAt(i);
            if (Character.isLetterOrDigit(c)) {  //알파벳, 숫자가 들어오면 true, 그 외엔 false
                changed_fn[++top] = c; //c삽입
            } else if (c == '(') {  // 왼쪽 괄호인 경우
                stack.push(c); //스택에 삽입
            } else if (c == ')') {  // 오른쪽 괄호인 경우
                while (!stack.isEmpty() && stack.peek() != '(') { //스택이 비거나 왼쪽 괄호를 만날때까지
                    changed_fn[++top] = stack.pop(); //스택의 요소들을 pop하여 changed_fn에 삽입
                }
                if (!stack.isEmpty() && stack.peek() == '(') { //스택이 비거나 왼쪽 괄호가 있다면
                    stack.pop();  // '(' 제거
                }
            } else {  // 연산자인 경우
                while (!stack.isEmpty() && getPriority(c) <= getPriority(stack.peek())) { //비어있거나 c의 우선순위가 top의 우선순위보다 낮다면
                    changed_fn[++top] = stack.pop(); //스택의 요소들을 pop하여 changed_fn에 삽입
                }
                stack.push(c); //스택에 삽입
            }
        }

        while (!stack.isEmpty()) {  // 스택에 남아있는 연산자 출력
            changed_fn[++top] = stack.pop();
        }
        return new String(changed_fn,0,top+1); //새로운 문자열을 반환
    }
    public static void main(String[] args) throws IOException {
        File f = new File("C:\\Users\\8146q\\IdeaProjects\\DS_06_202002546\\src\\input.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();
        while(line != null) {
            line = line.replaceAll("\\s+",""); //line의 공백을 제거
            String newline = Change(line);
            for(int i = 0; i<newline.length();i++){
                System.out.print(newline.charAt(i)+" ");
            }
            System.out.println();
            line = br.readLine();
        }

    }

}