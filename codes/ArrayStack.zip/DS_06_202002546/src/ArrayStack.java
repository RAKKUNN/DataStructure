import java.util.EmptyStackException;

public class ArrayStack {
    private char[] stack; //배열 이용
    private int top; //최상단 요소
    private int size; //스택 크기

    public ArrayStack(int size) {
        this.stack = new char[size];
        this.top = -1;
        this.size = size;
    }

    public int size() {
        return this.top + 1;
    }

    public boolean isEmpty() {
        return this.top == -1;
    }

    public char peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return this.stack[top];
    }

    public void resize(int newSize) {
        char[] newStack = new char[newSize];
        for (int i = 0; i <= top; i++) {
            newStack[i] = this.stack[i];
        }
        this.stack = newStack;
        this.size = newSize;
    }

    public void push(char value) {
        if (size() == this.size) {
            resize(this.size * 2);
        }
        this.stack[++top] = value;
    }

    public char pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        char value = this.stack[top];
        this.stack[top--] = '\0';
        if (size() > 0 && size() == this.size / 4) {
            resize(this.size / 2);
        }
        return value;
    }
}