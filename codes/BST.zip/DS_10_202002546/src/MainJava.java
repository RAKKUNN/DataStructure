import java.io.*;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainJava {
    public static void main(String[] args) {
        ArrayList<String> Line = readFile();
        while(!Line.isEmpty())
        {
            BST tree = new BST();
            String[] splited = Line.remove(0).split(" ");
            int k = Integer.valueOf(Line.remove(0));

            for(int i = 0; i < splited.length; i++){
                int key = Integer.valueOf(splited[i]);
                tree.put(key, 0);
            }
            tree.inorder(tree.getRoot());
            System.out.println();
            tree.delete_kthSmallest(k);
            tree.inorder(tree.getRoot());
            System.out.println("\n= = = = = = =");
        }
    }

    private static ArrayList<String> readFile() {
        ArrayList<String> aLines = null;
        try {
            String filePath = "C:\\Users\\8146q\\IdeaProjects\\DS_10_202002546\\src\\input.txt";
            File file = new File(filePath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            String line = "";
            aLines = new ArrayList<String>();
            while((line = br.readLine())!=null){
                aLines.add(line);
            }
            br.close();
            fr.close();
        }catch (Exception e){}
        return aLines;

    }
}