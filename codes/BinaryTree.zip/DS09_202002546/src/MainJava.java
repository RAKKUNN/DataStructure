
public class MainJava {
    public static void main(String[] args){

        Node node1 = new Node(4, null, null);
        Node node2 = new Node(5, null, null);
        Node node3 = new Node(2, null, null);
        Node node4 = new Node(3, node1, node2);
        Node node5 = new Node(1, node3, node4);
        BinaryTree tree = new BinaryTree(node5);

        //출력부
        System.out.print("Inorder: ");
        tree.inorder(node5);

        System.out.print("\nPath length: ");
        int lng = tree.pathLength(node5,5);
        System.out.print(lng);

        System.out.print("\nNumber of leaves: ");
        int cnt = tree.numLeaves(node5);
        System.out.print(cnt);


    }
}