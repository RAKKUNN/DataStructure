import java.io.*;
public class MainJava {
    public static void main(String[] args) throws Exception{
        File file = new File("C:\\Users\\8146q\\IdeaProjects\\DS_05_202002546\\src\\input.txt");
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        SinglyLinkedList list1 = new SinglyLinkedList(); //단순 연결 리스트 객체 생성
        SinglyLinkedList list2 = new SinglyLinkedList();


        String s1 = br.readLine(); //큰 정수 문자열로 받아서 정수로 바꾸고 list1 객체에 삽입 (list2도 동일)
        int len1 = s1.length()-3;
        int[] arr1 = new int[len1];
        for(int i = 0; i<len1;i++){
            arr1[i] = s1.charAt(i)-48;
            list1.insertNumber(arr1[i]);
        }
        list1.printNumber();


        String s2 = br.readLine();
        int len2 = s2.length();
        int[] arr2 = new int[len2];
        for(int i = 0; i<len2;i++){
            arr2[i] = s2.charAt(i)-48;
            list2.insertNumber(arr2[i]);
        }
        list2.printNumber();


        list1.add(list2);
        list1.printNumber();

    }
}
