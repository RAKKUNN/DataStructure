public class SinglyLinkedList {
    class Node { //노드 클래스
        private int data;
        private Node next;

        Node(int data) {
            this.data = data;
        }

        Node(int data, Node next) {
            this.data = data;
            this.next = next;
        }

        public int getData() {
            return this.data;
        }

        public Node getNext() {
            return this.next;
        }

        public void setData(int newData) {
            this.data = newData;
        }

        public void setNext(Node newNext) {
            this.next = newNext;
        }


    }
    Node first = null; //맨 앞 노드 초기화

    void insertNumber(int x) { //삽입 메서드 : 새로운 노드 만들고 비어있는지 확인하고 삽입
        Node newNode = new Node(x);
        if (first == null) {
            first = newNode;
            return;
        }
        newNode.next = first;
        first = newNode;

    }

    void add(SinglyLinkedList sec) { //각 list에 저장되어있는 큰 두 정수를 더하고 list1에 저장하는 메서드
        Node current1 = this.first; //list1 순회
        Node current2 = sec.first; //list2 순회
        Node result = null;
        Node previous = null;
        int carry = 0; //첫자리 수에 캐리값 0

        while (current1 != null && current2 != null) {
            int sum = current1.data + current2.data + carry; //sum = list1노드 데이터 + list2노드 데이터 + 캐리값
            carry = sum / 10; //캐리값
            sum = sum % 10; //합을 10으로 나눠서 그 나머지를 sum에 저장한다

            Node node = new Node(sum); //sum을 값으로 갖는 새 노드 생성

            if (result == null) {
                result = node;
                previous = node;
            } else {
                previous.next = node;
                previous = node;
            }

            current1 = current1.next; //다음 노드로
            current2 = current2.next; //다음 노드로
        }


        if (carry != 0) { //캐리값이 0이 아닐 경우
            Node node = new Node(carry); //캐리값을 갖는 노드 생성
            previous.next = node;
            previous = node;
        }
        this.first = reverseList(result); //뒤집기
    }

    void printNumber() { //출력함수/재귀함수를 호출해서 리스트내의 항목을 출력한다
        if (first == null) { //비어있으면 개행처리 후 종료
            System.out.println();
            return;
        }
        printNumberRecursive(first); //첫 노드 재귀 호출
        System.out.println();
    }

    void printNumberRecursive(Node current) {//맨앞 노드를 받아와 마지막 노드까지 출력한다
        if (current == null) { //마지막 노드에 도달하면 재귀 호출을 끝낸다.
            return;
        }
        printNumberRecursive(current.next); //재귀 호출
        System.out.print(current.data); //현재 노드 값 출력
    }

    Node reverseList(Node first) { //리스트를 뒤집어주는 역할
        Node previous = null;
        Node current = first;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = previous;
            previous = current;
            current = next;
        }
        return previous;
    }
}

