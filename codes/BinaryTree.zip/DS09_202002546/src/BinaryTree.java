import java.util.*;
public class BinaryTree {
    private Node root;
    public BinaryTree(){ root = null; }
    public BinaryTree(Node root){ this.root = root; }
    public Node getRoot(){ return root; }
    public void setRoot(Node newRoot){ root = newRoot; }
    public boolean isEmpty(){ return root == null; }

    public void inorder(Node n){
        if(n != null){
            inorder(n.getLeft());
            System.out.print(n.getKey()+" ");
            inorder(n.getRight());
        }
    }
    public int numLeaves(Node n){
        int cnt = 0;
        if(n != null){
            if(n.getLeft() == null && n.getRight() == null){
                return 1;
            }else{
                return cnt = numLeaves(n.getLeft())+numLeaves(n.getRight());
            }
        }
        return cnt;
    }

    public int count(Node n){
        if(n==null){
            return 0;
        }else{
            return count(n.getLeft())+count(n.getRight())+1;
        }
    }
    public int pathLength(Node n, int k){
        if(k==1||k==0) {
            return 0;
        }
        int numOfLeftNodes = count(n.getLeft());
        int numOfRightNodes = count(n.getRight());
        return pathLength(n.getLeft(),numOfLeftNodes)+pathLength(n.getRight(),numOfRightNodes)+k-1;

    }

}
