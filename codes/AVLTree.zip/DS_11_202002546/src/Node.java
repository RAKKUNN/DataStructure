public class Node<Key extends Comparable<Key>,Value>{
    Key id;
    Value name;
    public int height;
    Node<Key,Value> left;
    Node<Key,Value> right;
    int leftsize;


    public int height(Node n) {
        return n.height;
    }
    public int getHeight(){
        return height;
    }

    public Node(Key newID, Value newName, int newHt){
        id = newID;
        name = newName;
        height = newHt;
        left = right = null;
        leftsize = 0;
    }
    public Key getKey(){
        return id;
    }

    public Node<Key,Value> getLeft(){ return left; }
    public Node<Key,Value> getRight(){ return right; }
    public void setLeft(Node<Key,Value> lt){
        left = lt;
        updateLeftSize();
    }

    public void setRight(Node<Key,Value> rt){
        right = rt;
        updateLeftSize();
    }

    private void updateLeftSize() {
        int leftSize = (left != null) ? left.getLeftSize() + 1 : 0;
        leftsize = leftSize;
    }


    public void setHeight(int i) {
        this.height = i;
    }

    public int getLeftSize() {
        return left != null ? left.leftsize + 1 : 0;
    }

}
