public class AVLTree<Key extends Comparable<Key>,Value>{
    private Node<Key,Value> root;
    public AVLTree(){ root = null; }
    int k;
    int height(Node<Key,Value> n){
        if(n == null) return 0;
        return n.getHeight();
    }
    public int getLeftSize() {
        if (root == null) {
            return 0;
        }
        return size(root.getLeft());
    }

    public Node<Key,Value> getRoot(){ return root; }
    public void setRoot(Node<Key,Value> newRoot){ root = newRoot; }
    private Node<Key,Value> rotateRight(Node<Key,Value> n){
        Node<Key,Value> x = n.getLeft();
        n.setLeft(x.getRight());
        x.setRight(n);
        n.setHeight(tallerHeight(height(n.getLeft()), height(n.getRight())) + 1);
        x.setHeight(tallerHeight(height(x.getLeft()), height(n.getRight())) + 1);
        return x;
    }
    private Node<Key,Value> rotateLeft(Node<Key,Value> n){
        Node<Key, Value> x = n.right;
        n.setRight(x.getLeft());
        x.setLeft(n);
        n.setHeight(tallerHeight(height(n.getLeft()), height(n.getRight())) + 1);
        x.setHeight(tallerHeight(height(x.getLeft()), height(x.getRight())) + 1);
        return x;
    }
    private int tallerHeight(int k, int t){
        if(k>t) return k;
        else return t;
    }
    private int size(Node<Key, Value> n) {
        if (n == null) {
            return 0;
        }
        return size(n.getLeft()) + size(n.getRight()) + 1;
    }
    public void put(Key k, Value v){
        root = put(root,k,v);
    }
    private Node<Key,Value> put(Node<Key,Value> n, Key k, Value v){
        if(n == null) return new Node<Key,Value>(k,v,1);
        int t = k.compareTo(n.getKey());
        if(t<0) {
            n.setLeft(put(n.getLeft(), k, v));
            n.leftsize = size(n.getLeft());
        }
        else if(t>0) n.setRight(put(n.getRight(), k, v));
        else{
            n.name = v;
            return n;
        }
        n.setHeight(tallerHeight(height(n.getLeft()), height(n.getRight())) + 1);
        return balance(n);
    }

    private Node<Key, Value> balance(Node<Key, Value> n) {
        if (bf(n) > 1) {
            if (bf(n.getLeft()) < 0) {
                n.setLeft(rotateLeft(n.getLeft()));
            }
            n = rotateRight(n);
        } else if (bf(n) < -1) {
            if (bf(n.getRight()) > 0) {
                n.setRight(rotateRight(n.getRight()));
            }
            n = rotateLeft(n);
        }
        return n;
    }
    private int bf(Node<Key, Value> n) {
        return height(n.getLeft()) - height(n.getRight());
    }

    public void preorder(Node<Key, Value> n) {
        if (n != null) {
            System.out.print(n.getKey() + " ");
            preorder(n.getLeft());
            preorder(n.getRight());
        }
    }

    public void deleteKth(int k) {
        if (root == null) {
            System.out.println("empty tree");
            return;
        }

        if (k <= 0 || k > size(root)) {
            System.out.println("Invalid k");
            return;
        }

        root = deleteKth(root, k);
    }
    private Node<Key, Value> min(Node<Key, Value> n) {
        if (n.getLeft() == null) {
            return n;
        }
        return min(n.getLeft());
    }

    public Node<Key, Value> deleteMin(Node<Key, Value> n) {
        if (n.getLeft() == null) {
            return n.getRight();
        }
        n.setLeft(deleteMin(n.getLeft()));
        return n;
    }

    private Node<Key, Value> deleteKth(Node<Key, Value> node, int k) {
        if (node == null) {
            return null;
        }

        int leftSize = size(node.getLeft()) + 1;

        if (k < leftSize) {
            node.setLeft(deleteKth(node.getLeft(), k));
            node.leftsize--;
        } else if (k > leftSize) {
            node.setRight(deleteKth(node.getRight(), k - leftSize));
        } else {
            if (node.getLeft() == null && node.getRight() == null) {
                return null;
            } else if (node.getLeft() == null) {
                return node.getRight();
            } else if (node.getRight() == null) {
                return node.getLeft();
            } else {
                Node<Key, Value> N_Node = min(node.getRight());
                N_Node.setRight(deleteMin(node.getRight()));
                N_Node.setLeft(node.getLeft());
                node = N_Node;
            }
        }

        node.setHeight(tallerHeight(height(node.getLeft()), height(node.getRight())) + 1);
        return balance(node);
    }

}
